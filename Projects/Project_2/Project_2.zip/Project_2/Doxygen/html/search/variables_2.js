var searchData=
[
  ['ncards_0',['NCARDS',['../class_card.html#ac568afd578beb492be77e3555ca80a1c',1,'Card']]]
];
