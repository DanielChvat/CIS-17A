var searchData=
[
  ['ncards_0',['NCARDS',['../class_card.html#ac568afd578beb492be77e3555ca80a1c',1,'Card']]],
  ['nine_1',['Nine',['../_face_8h.html#ad3fc1d97a3c41ea9d58d0ab14f75294fa24db11216549ee55172c33cf3def2f3f',1,'Face.h']]]
];
