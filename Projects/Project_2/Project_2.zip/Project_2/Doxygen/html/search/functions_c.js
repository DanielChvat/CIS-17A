var searchData=
[
  ['trnslte_0',['trnslte',['../class_card.html#a97e5b8dc27043f29c7f9a5c31139fa2f',1,'Card']]]
];
