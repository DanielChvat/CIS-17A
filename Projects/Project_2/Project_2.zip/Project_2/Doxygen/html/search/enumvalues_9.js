var searchData=
[
  ['ten_0',['Ten',['../_face_8h.html#ad3fc1d97a3c41ea9d58d0ab14f75294faa185c3c138dca5ef46afc33288a67d1f',1,'Face.h']]],
  ['three_1',['Three',['../_face_8h.html#ad3fc1d97a3c41ea9d58d0ab14f75294faca8a2087e5557e317599344687a57391',1,'Face.h']]],
  ['two_2',['Two',['../_face_8h.html#ad3fc1d97a3c41ea9d58d0ab14f75294faaada29daee1d64ed0fe907043855cb7e',1,'Face.h']]]
];
