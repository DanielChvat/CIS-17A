var searchData=
[
  ['cardsel_0',['cardSel',['../class_card.html#a726a83c5e049988696e35a565c9d35a4',1,'Card']]],
  ['cols_1',['cols',['../struct_stats.html#a6f7f7869b04f2c473a950ea5015b5db4',1,'Stats']]],
  ['crd_2',['crd',['../class_card.html#a8b792e92d7988f7ad49015438b8a4ed4',1,'Card']]],
  ['csut_3',['cSut',['../class_card.html#a4cee816f5cb943c3a1a3d8d24a13bdb9',1,'Card']]]
];
