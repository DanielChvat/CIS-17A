var searchData=
[
  ['five_0',['Five',['../_face_8h.html#ad3fc1d97a3c41ea9d58d0ab14f75294fae5d9de39f7ca1ba2637e5640af3ae8aa',1,'Face.h']]],
  ['four_1',['Four',['../_face_8h.html#ad3fc1d97a3c41ea9d58d0ab14f75294fa981b8fcee42e1e726a67a2b9a98ea6e9',1,'Face.h']]]
];
