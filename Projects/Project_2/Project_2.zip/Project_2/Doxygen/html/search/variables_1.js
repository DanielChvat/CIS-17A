var searchData=
[
  ['data_0',['data',['../struct_stats.html#ac4e68f82426bbb8f5af4c9391b4fdfd1',1,'Stats']]]
];
