var searchData=
[
  ['jack_0',['Jack',['../_face_8h.html#ad3fc1d97a3c41ea9d58d0ab14f75294fa40687c8206d15373954d8b27c6724f62',1,'Face.h']]]
];
