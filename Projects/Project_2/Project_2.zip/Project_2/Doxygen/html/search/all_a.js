var searchData=
[
  ['king_0',['King',['../_face_8h.html#ad3fc1d97a3c41ea9d58d0ab14f75294fa719ef271d38a388fd7b2bc967f4bd885',1,'Face.h']]]
];
