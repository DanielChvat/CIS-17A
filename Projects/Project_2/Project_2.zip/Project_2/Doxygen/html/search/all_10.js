var searchData=
[
  ['queen_0',['Queen',['../_face_8h.html#ad3fc1d97a3c41ea9d58d0ab14f75294fa2c2d2c0291163b077a372c2a9c5a6eda',1,'Face.h']]]
];
