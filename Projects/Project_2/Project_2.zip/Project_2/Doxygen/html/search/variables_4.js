var searchData=
[
  ['rows_0',['rows',['../struct_stats.html#ac96667dcd3829e47907b455ff9a6b59c',1,'Stats']]]
];
