var searchData=
[
  ['incdval_0',['incDVal',['../class_game.html#ad8d6903c7c451d7f493d3291fa3ad5fd',1,'Game']]],
  ['init_1',['init',['../class_abs_player.html#a55674144b4c428017ec52169614cfaaf',1,'AbsPlayer::init()'],['../class_player.html#a015ea21fa1e7273e47d48cb20d9b12e3',1,'Player::init()']]]
];
