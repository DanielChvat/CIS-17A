var searchData=
[
  ['suitsel_0',['suitSel',['../class_card.html#a53d3cb8566d8f003486782d76b507743',1,'Card']]]
];
