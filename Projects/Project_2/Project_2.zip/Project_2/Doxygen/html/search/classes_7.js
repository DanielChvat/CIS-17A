var searchData=
[
  ['stats_0',['Stats',['../struct_stats.html',1,'']]]
];
