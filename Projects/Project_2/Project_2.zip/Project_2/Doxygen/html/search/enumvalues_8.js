var searchData=
[
  ['seven_0',['Seven',['../_face_8h.html#ad3fc1d97a3c41ea9d58d0ab14f75294fa12e67aac3e7f9227cc35f8f047d7dc74',1,'Face.h']]],
  ['six_1',['Six',['../_face_8h.html#ad3fc1d97a3c41ea9d58d0ab14f75294fae6fbc0b9673f8c86726688d7607fc8f5',1,'Face.h']]]
];
