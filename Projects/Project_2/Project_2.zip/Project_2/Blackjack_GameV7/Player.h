/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Player.h
 * Author: Daniel
 *
 * Created on December 15, 2022, 6:58 PM
 */

#ifndef PLAYER_H
#define PLAYER_H
#include "AbsPlayer.h"
/*class Player:public AbsPlayer{
private:
    char *name;
    const int NMSIZE=81;
    bool win;
    char again;
    char hit;
    float money;
    float strtMny;
    float bet;
    float prcChng;
private:
    //Default Constructor
    Player();
    //Copy Constructor
    Player(const Player &);
    void setName(char *);
    void setWin(bool);
    void setAgn(char);
    void setHit(char);
    void setMny(float);
    void setSMny(float);
    void setBet(float);
    void getPC();
    char *getName();
    bool getWin();
    char getAgn();
    char getHit();
    float getMny();
    float getSMny();
    float getBet();
};
*/
#endif /* PLAYER_H */

