/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Face.h
 * Author: Daniel
 *
 * Created on December 15, 2022, 4:26 PM
 */

#ifndef FACE_H
#define FACE_H

enum class Face {
    Ace   = 1,
    Two   = 2,
    Three = 3,
    Four  = 4,
    Five  = 5,
    Six   = 6,
    Seven = 7,
    Eight = 8,
    Nine  = 9,
    Ten   = 10,
    Queen = 10,
    King  = 10,
    Jack  = 10
};

#endif /* FACE_H */

